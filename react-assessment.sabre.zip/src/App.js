import logo from "./logo.svg";
import "./App.css";
import Rule from "./components/Rule";

function App() {
  document.title = `Greetings to `;
  return (
    <>
      <Rule />
    </>
  );
}

export default App;
