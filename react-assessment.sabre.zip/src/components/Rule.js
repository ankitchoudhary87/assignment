import React, { useState } from "react";
import {
  mapAttributeInput,
  mapAttributeButton,
  mapAttributeOperator,
  definedValue,
} from "../util/mapAttribute";
import {
  initialFormState,
  operatorAssignmentState,
} from "../stateData/stateData";
const Rule = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [operators, setOperators] = useState(operatorAssignmentState);

  // here we are handling input onchange like pcc, airlne code , pcc country code, gds code, allow, priority,start date, expired date
  const handleformData = (
    event,
    paramCode = "",
    logicalOperator = "",
    operatorAssignment = ""
  ) => {
    const { name, value } = event;

    if (name === "ruleName") {
      setFormData((prev) => {
        return {
          ...prev,
          [name]: value,
          ruleSetName: value,
          lastUpdateDate: new Date().toISOString(),
        };
      });
    }

    if (name === "expireDate" || name === "startDate") {
      setFormData((prev) => {
        return {
          ...prev,
          [name]: value,
          lastUpdateDate: new Date().toISOString(),
        };
      });
    }

    if (name === "ruleResult") {
      setFormData((prev) => {
        return {
          ...prev,
          lastUpdateDate: new Date().toISOString(),
          ruleGroup: {
            ...prev.ruleGroup,
            ruleResult: {
              ...prev.ruleGroup.ruleResult,
              attributeValue: value,
            },
          },
        };
      });
    }

    if (name === "priority") {
      setFormData((prev) => {
        return {
          ...prev,
          lastUpdateDate: new Date().toISOString(),
          ruleGroup: {
            ...prev.ruleGroup,
            priority: value,
          },
        };
      });
    }

    if (
      name === "pcc_input" ||
      name === "airline_code_input" ||
      name === "pcc_country_code_input" ||
      name === "gds_code_input" ||
      name === "segment_arrival_date" ||
      name === "segment_departure_date"
    ) {
      const newState = JSON.parse(
        JSON.stringify(formData.ruleGroup.attributeGroups[0])
      ).attributes.map((item, index) => {
        if (item.attributeLogicalOperator === logicalOperator) {
          return mapAttributeInput(item, paramCode, value, operatorAssignment);
        }
        return item;
      });
      setFormData((prevState) => {
        return {
          ...prevState,
          lastUpdateDate: new Date().toISOString(),
          ruleGroup: {
            ...prevState.ruleGroup,
            attributeGroups: [
              {
                ...prevState.ruleGroup.attributeGroups[0],
                attributes: newState,
              },
            ],
          },
        };
      });
    }
  };

  const handleOnButtonClick = (
    event,
    paramCode,
    logicalOperator,
    operatorAssignment
  ) => {
    const { value } = event;
    const newState = JSON.parse(
      JSON.stringify(formData.ruleGroup.attributeGroups[0])
    ).attributes.map((item, index) => {
      if (item.attributeLogicalOperator === logicalOperator) {
        if (paramCode === "SEGMENT_DATE") {
          const segmentDates = [
            "SEGMENT_ARRIVAL_DATE",
            "SEGMENT_DEPARTURE_DATE",
          ];
          segmentDates.forEach((datefield) => {
            return mapAttributeButton(item, datefield, value);
          });
        } else {
          return mapAttributeButton(item, paramCode, value);
        }
      }
      return item;
    });
    setFormData((prevState) => {
      return {
        ...prevState,
        lastUpdateDate: new Date().toISOString(),
        ruleGroup: {
          ...prevState.ruleGroup,
          attributeGroups: [
            {
              ...prevState.ruleGroup.attributeGroups[0],
              attributes: newState,
            },
          ],
        },
      };
    });
    setOperators((prev) => {
      return {
        ...prev,
        [paramCode]: {
          operator: prev[paramCode].operator,
          value: prev[paramCode].value,
          assignment: value,
        },
      };
    });
  };

  const handleOperator = (event, paramCode, logicalOperator) => {
    const ParseData = JSON.parse(
      JSON.stringify(formData.ruleGroup.attributeGroups[0].attributes)
    );
    const attributeIndx = ParseData.findIndex(
      (x) => x.attributeLogicalOperator === operators[paramCode].operator
    );
    if (paramCode === "SEGMENT_DATE") {
      const segmentDates = ["SEGMENT_ARRIVAL_DATE", "SEGMENT_DEPARTURE_DATE"];

      segmentDates.forEach((datefield) => {
        mapAttributeOperator(
          attributeIndx,
          ParseData,
          paramCode,
          operators,
          logicalOperator,
          datefield
        );
      });
    } else {
      mapAttributeOperator(
        attributeIndx,
        ParseData,
        paramCode,
        operators,
        logicalOperator
      );
    }

    setFormData((prevState) => {
      return {
        ...prevState,
        lastUpdateDate: new Date().toISOString(),
        ruleGroup: {
          ...prevState.ruleGroup,
          attributeGroups: [
            {
              ...prevState.ruleGroup.attributeGroups[0],
              attributes: ParseData,
            },
          ],
        },
      };
    });
    setOperators((prev) => {
      return {
        ...prev,
        [paramCode]: {
          assignment: prev[paramCode].assignment,
          value: prev[paramCode].value,
          operator: logicalOperator,
        },
      };
    });
  };

  const handleOnSubmit = (event) => {
    console.log("formData", formData);
  };

  return (
    <>
      <div className='container-fluid'>
        <div className='rule border border-2 mt-5 mb-5 mx-4 position-relative rounded-3 rule '>
          <form>
            <div className='col-md-4 mt-4 mx-4'>
              <div className='form-floating mb-3'>
                <input
                  type='text'
                  id='name'
                  className='form-control'
                  placeholder='Enter Rule Name...'
                  onChange={(e) => handleformData(e.target)}
                  value={formData.ruleName}
                  name='ruleName'
                />
                <label htmlFor='name'>Rule Name</label>
              </div>
            </div>

            <div className=' border-top '>
              <div className='rule_type  mt-2 mx-4'>
                <div className='rule_type_heading'>Defined Rule Type:</div>
                <div className='rule_type_pcc'>
                  <div className='row'>
                    <div className='col-5'>
                      <div className='d-flex bd-highlight mb-3'>
                        <div className='me-auto p-2 bd-highlight'>PCC</div>
                        <div className='p-2 bd-highlight'>
                          <button
                            className={`btn ${
                              operators.PCC.assignment === "EQ"
                                ? "btn-danger"
                                : "btn-secondary"
                            }`}
                            type='button'
                            value='EQ'
                            name='EQ'
                            onClick={(e) =>
                              handleOnButtonClick(
                                e.target,
                                "PCC",
                                operators.PCC.operator
                              )
                            }
                          >
                            =
                          </button>
                        </div>

                        <div className='p-2 bd-highlight'>
                          <button
                            className={`btn ${
                              operators.PCC.assignment === "NEQ"
                                ? "btn-danger"
                                : "btn-secondary"
                            }`}
                            type='button'
                            name='NEQ'
                            value='NEQ'
                            onClick={(e) =>
                              handleOnButtonClick(
                                e.target,
                                "PCC",
                                operators.PCC.operator
                              )
                            }
                          >
                            !=
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className='col-7'>
                      <div className='form-floating mb-3'>
                        <input
                          type='text'
                          id='name'
                          name='pcc_input'
                          className='form-control'
                          placeholder='Enter Rule Name...'
                          onChange={(e) =>
                            handleformData(
                              e.target,
                              "PCC",
                              operators.PCC.operator,
                              operators.PCC.assignment
                            )
                          }
                        />
                        <label htmlFor='name'>PCC</label>
                      </div>
                    </div>
                  </div>
                </div>

                <div className='rule_type_operation'>
                  {/* 1st */}
                  <div className='rule_type_operation_container'>
                    <div className='d-flex bd-highlight mb-3'>
                      <div className='p-2 bd-highlight'>
                        <button
                          className={`btn ${
                            operators.AIRLINE_CODE.operator === "AND"
                              ? "btn-danger"
                              : "btn-secondary"
                          }`}
                          type='button'
                          value='AND'
                          onClick={(e) =>
                            handleOperator(e.target, "AIRLINE_CODE", "AND")
                          }
                        >
                          AND
                        </button>
                      </div>

                      <div className='p-2 bd-highlight'>
                        <button
                          className={`btn ${
                            operators.AIRLINE_CODE.operator === "OR"
                              ? "btn-danger"
                              : "btn-secondary"
                          }`}
                          type='button'
                          name='OR'
                          onClick={(e) =>
                            handleOperator(e.target, "AIRLINE_CODE", "OR")
                          }
                        >
                          OR
                        </button>
                      </div>
                    </div>
                    <div className='row'>
                      <div className='col-5'>
                        <div className='d-flex bd-highlight mb-3'>
                          <div className='me-auto p-2 bd-highlight'>
                            AIRLINE CODE
                          </div>
                          <div className='p-2 bd-highlight'>
                            <button
                              className={`btn ${
                                operators.AIRLINE_CODE.assignment === "EQ"
                                  ? "btn-danger"
                                  : "btn-secondary"
                              }`}
                              type='button'
                              value='EQ'
                              // name='EQ'
                              onClick={(e) =>
                                handleOnButtonClick(
                                  e.target,
                                  "AIRLINE_CODE",
                                  operators.AIRLINE_CODE.operator
                                )
                              }
                            >
                              =
                            </button>
                          </div>

                          <div className='p-2 bd-highlight'>
                            <button
                              className={`btn ${
                                operators.AIRLINE_CODE.assignment === "NEQ"
                                  ? "btn-danger"
                                  : "btn-secondary"
                              }`}
                              type='button'
                              value='NEQ'
                              name='NEQ'
                              onClick={(e) =>
                                handleOnButtonClick(
                                  e.target,
                                  "AIRLINE_CODE",
                                  operators.AIRLINE_CODE.operator
                                )
                              }
                            >
                              !=
                            </button>
                          </div>
                        </div>
                      </div>
                      <div className='col-7'>
                        <div className='form-floating mb-3'>
                          <input
                            type='text'
                            id='name'
                            name='airline_code_input'
                            className='form-control'
                            placeholder=' AIRLINE CODE..'
                            onChange={(e) =>
                              handleformData(
                                e.target,
                                "AIRLINE_CODE",
                                operators.AIRLINE_CODE.operator,
                                operators.AIRLINE_CODE.assignment
                              )
                            }
                          />
                          <label htmlFor='name'> AIRLINE CODE</label>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 2nd */}
                  <div className='rule_type_operation_container'>
                    <div className='d-flex bd-highlight mb-3'>
                      <div className='p-2 bd-highlight'>
                        <button
                          className={`btn ${
                            operators.PCC_COUNTRY_CODE.operator === "AND"
                              ? "btn-danger"
                              : "btn-secondary"
                          }`}
                          type='button'
                          name='AND'
                          onClick={(e) =>
                            handleOperator(e.target, "PCC_COUNTRY_CODE", "AND")
                          }
                        >
                          AND
                        </button>
                      </div>

                      <div className='p-2 bd-highlight'>
                        <button
                          className={`btn ${
                            operators.PCC_COUNTRY_CODE.operator === "OR"
                              ? "btn-danger"
                              : "btn-secondary"
                          }`}
                          type='button'
                          name='OR'
                          onClick={(e) =>
                            handleOperator(e.target, "PCC_COUNTRY_CODE", "OR")
                          }
                        >
                          OR
                        </button>
                      </div>
                    </div>
                    <div className='row'>
                      <div className='col-5'>
                        <div className='d-flex bd-highlight mb-3'>
                          <div className='me-auto p-2 bd-highlight'>
                            PCC COUNTRY CODE
                          </div>
                          <div className='p-2 bd-highlight'>
                            <button
                              className={`btn ${
                                operators.PCC_COUNTRY_CODE.assignment === "EQ"
                                  ? "btn-danger"
                                  : "btn-secondary"
                              }`}
                              type='button'
                              name='EQ'
                              value='EQ'
                              onClick={(e) =>
                                handleOnButtonClick(
                                  e.target,
                                  "PCC_COUNTRY_CODE",
                                  operators.PCC_COUNTRY_CODE.operator
                                )
                              }
                            >
                              =
                            </button>
                          </div>

                          <div className='p-2 bd-highlight'>
                            <button
                              className={`btn ${
                                operators.PCC_COUNTRY_CODE.assignment === "NEQ"
                                  ? "btn-danger"
                                  : "btn-secondary"
                              }`}
                              type='button'
                              name='NEQ'
                              value='NEQ'
                              onClick={(e) =>
                                handleOnButtonClick(
                                  e.target,
                                  "PCC_COUNTRY_CODE",
                                  operators.PCC_COUNTRY_CODE.operator
                                )
                              }
                            >
                              !=
                            </button>
                          </div>
                        </div>
                      </div>
                      <div className='col-7'>
                        <div className='form-floating mb-3'>
                          <input
                            type='text'
                            id='name'
                            name='pcc_country_code_input'
                            className='form-control'
                            placeholder=' AIRLINE CODE..'
                            onChange={(e) =>
                              handleformData(
                                e.target,
                                "PCC_COUNTRY_CODE",
                                operators.PCC_COUNTRY_CODE.operator,
                                operators.PCC_COUNTRY_CODE.assignment
                              )
                            }
                          />
                          <label htmlFor='name'> PCC COUNTRY CODE</label>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* {3 rd} */}
                  <div className='rule_type_operation_container'>
                    <div className='d-flex bd-highlight mb-3'>
                      <div className='p-2 bd-highlight'>
                        <button
                          className={`btn ${
                            operators.GDS_CODE.operator === "AND"
                              ? "btn-danger"
                              : "btn-secondary"
                          }`}
                          type='button'
                          name='AND'
                          onClick={(e) =>
                            handleOperator(e.target, "GDS_CODE", "AND")
                          }
                        >
                          AND
                        </button>
                      </div>

                      <div className='p-2 bd-highlight'>
                        <button
                          className={`btn ${
                            operators.GDS_CODE.operator === "OR"
                              ? "btn-danger"
                              : "btn-secondary"
                          }`}
                          type='button'
                          name='OR'
                          onClick={(e) =>
                            handleOperator(e.target, "GDS_CODE", "OR")
                          }
                        >
                          OR
                        </button>
                      </div>
                    </div>
                    <div className='row'>
                      <div className='col-5'>
                        <div className='d-flex bd-highlight mb-3'>
                          <div className='me-auto p-2 bd-highlight'>
                            GDS CODE
                          </div>
                          <div className='p-2 bd-highlight'>
                            <button
                              className={`btn ${
                                operators.GDS_CODE.assignment === "EQ"
                                  ? "btn-danger"
                                  : "btn-secondary"
                              }`}
                              type='button'
                              name='EQ'
                              value='EQ'
                              onClick={(e) =>
                                handleOnButtonClick(
                                  e.target,
                                  "GDS_CODE",
                                  operators.GDS_CODE.operator
                                )
                              }
                            >
                              =
                            </button>
                          </div>

                          <div className='p-2 bd-highlight'>
                            <button
                              className={`btn ${
                                operators.GDS_CODE.assignment === "NEQ"
                                  ? "btn-danger"
                                  : "btn-secondary"
                              }`}
                              type='button'
                              name='NEQ'
                              value='NEQ'
                              onClick={(e) =>
                                handleOnButtonClick(
                                  e.target,
                                  "GDS_CODE",
                                  operators.GDS_CODE.operator
                                )
                              }
                            >
                              !=
                            </button>
                          </div>
                        </div>
                      </div>
                      <div className='col-7'>
                        <div className='form-floating mb-3'>
                          <input
                            type='text'
                            id='name'
                            name='gds_code_input'
                            className='form-control'
                            placeholder=' GDS CODE..'
                            onChange={(e) =>
                              handleformData(
                                e.target,
                                "GDS_CODE",
                                operators.GDS_CODE.operator,
                                operators.GDS_CODE.assignment
                              )
                            }
                          />
                          <label htmlFor='name'> GDS CODE</label>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* {4thssss} */}
                  <div className='rule_type_operation_container'>
                    <div className='d-flex bd-highlight mb-3'>
                      <div className='p-2 bd-highlight'>
                        <button
                          className={`btn ${
                            operators.SEGMENT_DATE.operator === "AND"
                              ? "btn-danger"
                              : "btn-secondary"
                          }`}
                          type='button'
                          name='AND'
                          onClick={(e) =>
                            handleOperator(e.target, "SEGMENT_DATE", "AND")
                          }
                        >
                          AND
                        </button>
                      </div>

                      <div className='p-2 bd-highlight'>
                        <button
                          className={`btn ${
                            operators.SEGMENT_DATE.operator === "OR"
                              ? "btn-danger"
                              : "btn-secondary"
                          }`}
                          type='button'
                          name='OR'
                          onClick={(e) =>
                            handleOperator(e.target, "SEGMENT_DATE", "OR")
                          }
                        >
                          OR
                        </button>
                      </div>
                    </div>
                    <div className='row'>
                      <div className='col-5'>
                        <div className='d-flex bd-highlight mb-3'>
                          <div className='me-auto p-2 bd-highlight'>
                            SEGMENT DATE
                          </div>
                          <div className='p-2 bd-highlight'>
                            <button
                              className={`btn ${
                                operators.SEGMENT_DATE.assignment === "DATE_EQ"
                                  ? "btn-danger"
                                  : "btn-secondary"
                              }`}
                              type='button'
                              name='DATE_EQ'
                              value='DATE_EQ'
                              onClick={(e) =>
                                handleOnButtonClick(
                                  e.target,
                                  "SEGMENT_DATE",
                                  operators.SEGMENT_DATE.operator,
                                  operators.SEGMENT_DATE.assignment
                                )
                              }
                            >
                              =
                            </button>
                          </div>

                          <div className='p-2 bd-highlight'>
                            <button
                              className={`btn ${
                                operators.SEGMENT_DATE.assignment === "DATE_NEQ"
                                  ? "btn-danger"
                                  : "btn-secondary"
                              }`}
                              type='button'
                              name='DATE_NEQ'
                              value='DATE_NEQ'
                              onClick={(e) =>
                                handleOnButtonClick(
                                  e.target,
                                  "SEGMENT_DATE",
                                  operators.SEGMENT_DATE.operator,
                                  operators.SEGMENT_DATE.assignment
                                )
                              }
                            >
                              !=
                            </button>
                          </div>
                        </div>
                      </div>
                      <div className='col-7'>
                        <div className='row'>
                          <div className='col'>
                            <div className='form-floating mb-3'>
                              <input
                                type='date'
                                id='segment_departure_date'
                                name='segment_departure_date'
                                className='form-control'
                                placeholder='SEGMENT DATE'
                                onChange={(e) =>
                                  handleformData(
                                    e.target,
                                    "SEGMENT_DEPARTURE_DATE",
                                    operators.SEGMENT_DATE.operator,
                                    operators.SEGMENT_DATE.assignment
                                  )
                                }
                              />
                              <label htmlFor='segment_departure_date'>
                                SEGMENT Departure DATE
                              </label>
                            </div>
                          </div>

                          <div className='col'>
                            <div className='form-floating mb-3'>
                              <input
                                type='date'
                                id='segment_arrival_date'
                                name='segment_arrival_date'
                                className='form-control'
                                placeholder='SEGMENT Arrival DATE'
                                onChange={(e) =>
                                  handleformData(
                                    e.target,
                                    "SEGMENT_ARRIVAL_DATE",
                                    operators.SEGMENT_DATE.operator,
                                    operators.SEGMENT_DATE.assignment
                                  )
                                }
                              />
                              <label htmlFor='segment_arrival_date'>
                                {" "}
                                SEGMENT Arrival DATE
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className='border border-2 p-4 rule_values'>
              <div className='row'>
                <div className='col-3'>
                  <div className='p-2'>DEFINED RULE VALUES :</div>
                </div>
                <div className='bg-secondary border border-dark col-8 mx-1'>
                  <div className=' bd-highlight'>{definedValue(operators)}</div>
                </div>
              </div>
            </div>

            <div className='rule_result my-3 mx-4'>
              <div className='row'>
                <div className='col'>
                  <div className='rule_type_heading mb-3'>Rule Result</div>
                  <select
                    className='form-select form-select-lg mb-3'
                    aria-label='.form-select-lg'
                    onChange={(e) => handleformData(e.target)}
                    name='ruleResult'
                  >
                    <option value='Allow'>Allow</option>
                    <option value='Deny'>Deny</option>
                  </select>
                </div>

                <div className='col'>
                  <div className='rule_type_heading mb-3'>Priority</div>

                  <select
                    className='form-select form-select-lg mb-3'
                    aria-label='.form-select-lg '
                    onChange={(e) => handleformData(e.target)}
                    name='priority'
                  >
                    <option value='1'>1</option>
                    <option value='2'>2</option>
                  </select>
                </div>

                <div className='col'>
                  <div className='rule_type_heading mb-3'>
                    Applicability start Date
                  </div>
                  <div className='form-floating mb-3'>
                    <input
                      type='datetime-local'
                      id='applicability_start_date'
                      name='startDate'
                      className='form-control'
                      placeholder='Applicability start Date'
                      onChange={(e) => handleformData(e.target)}
                    />
                    <label htmlFor='applicability_start_date'>
                      Applicability start Date
                    </label>
                  </div>
                </div>

                <div className='col'>
                  <div className='rule_type_heading mb-3'>
                    Applicability End Date
                  </div>

                  <div className='form-floating mb-3'>
                    <input
                      type='datetime-local'
                      id='Applicability_end_date'
                      name='expireDate'
                      className='form-control'
                      onChange={(e) => handleformData(e.target)}
                      placeholder='Applicability End Dates'
                    />
                    <label htmlFor='segment_arrival'>
                      Applicability End Date
                    </label>
                  </div>
                </div>
              </div>
            </div>
            <div className=' my-5 mx-2 d-flex justify-content-end'>
              <div className='mx-2 '>
                <button
                  className='btn-default'
                  type='button'
                  name='cancel'
                  value='cancel'
                >
                  CANCEL
                </button>
              </div>

              <div className=''>
                <button
                  className='btn-secondary bg-dark'
                  type='button'
                  ssssss
                  name='save'
                  value='save'
                  onClick={(e) => handleOnSubmit(e)}
                >
                  SAVE
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default Rule;
