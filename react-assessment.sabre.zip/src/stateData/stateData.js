export const initialFormState = {
  ruleState: "FUTURE",
  ruleName: "",
  productType: ["AIR"],
  ruleSetName: "",
  isActive: true,
  version: 1,
  ruleGroup: {
    ruleResult: {
      attributeKey: "Blacklist PCC",
      attributeValue: "",
      ruleFunction: "Blacklist",
    },
    priority: "",
    attributeGroups: [
      {
        attributeGroup: null,
        attributes: [
          {
            attributeLogicalOperator: "AND",
            parameters: [],
          },
          {
            attributeLogicalOperator: "OR",
            parameters: [],
          },
        ],
      },
    ],
  },
  startDate: null,
  expireDate: null,
  lastUpdatedBy: null,
  lastUpdateDate: null,
};

export const operatorAssignmentState = {
  PCC: {
    operator: "AND",
    assignment: "EQ",
    value: "PCC",
  },
  AIRLINE_CODE: {
    operator: "AND",
    assignment: "EQ",
    value: "AIRLINE CODE",
  },
  PCC_COUNTRY_CODE: {
    operator: "AND",
    assignment: "EQ",
    value: "PCC COUNTRY CODE",
  },
  GDS_CODE: {
    operator: "AND",
    assignment: "EQ",
    value: "GDS CODE",
  },
  SEGMENT_DATE: {
    operator: "AND",
    assignment: "DATE_EQ",
    value: "SEGMENT DATE",
  },
};
