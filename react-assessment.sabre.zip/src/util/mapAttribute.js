import { v4 as uuidv4 } from "uuid";

export const mapAttributeInput = (
  item,
  paramCode,
  value,
  operatorAssignment
) => {
  const paramIndex = item.parameters.findIndex(
    (x) => x.parameter === paramCode
  );
  if (paramIndex > -1) {
    item.parameters[paramIndex] = {
      ...item.parameters[paramIndex],
      parameter: paramCode,
      values: value,
    };
  } else {
    item.parameters.push({
      order: uuidv4(),
      parameter: paramCode,
      operator: operatorAssignment,
      values: value,
      isDupe: false,
    });
  }
  return item;
};

export const mapAttributeButton = (item, paramCode, value) => {
  const paramIndex = item.parameters.findIndex(
    (x) => x.parameter === paramCode
  );
  if (paramIndex > -1) {
    item.parameters[paramIndex] = {
      ...item.parameters[paramIndex],
      parameter: paramCode,
      operator: value,
    };
  } else {
    item.parameters.push({
      order: uuidv4(),
      parameter: paramCode,
      operator: value,
      values: "",
      isDupe: false,
    });
  }
  return item;
};

export const mapAttributeOperator = (
  attributeIndex,
  ParseData,
  paramCode,
  operators,
  logicalOperator,
  datefield = ""
) => {
  const paramIndexx = ParseData[attributeIndex].parameters.findIndex((x) =>
    x.parameter === datefield ? datefield : paramCode
  );
  if (paramIndexx > -1 && operators[paramCode].operator !== logicalOperator) {
    const attributeInxxx = ParseData.findIndex(
      (x) => x.attributeLogicalOperator === logicalOperator
    );
    ParseData[attributeInxxx].parameters.push(
      ParseData[attributeIndex].parameters[paramIndexx]
    );
    ParseData[attributeIndex].parameters.splice(paramIndexx, 1);
  }
  return ParseData;
};

export const definedValue = (operators) => {
  let startAndValue = "";
  let endAndValue = "";
  let orValue = "";
  startAndValue += operators.PCC.value;
  if (operators.AIRLINE_CODE.operator) {
    startAndValue += " " + operators.AIRLINE_CODE.operator;
    if (
      operators.PCC_COUNTRY_CODE.operator === "OR" ||
      operators.GDS_CODE.operator === "OR" ||
      operators.SEGMENT_DATE.operator === "OR" ||
      operators.AIRLINE_CODE.operator === "OR"
    ) {
      orValue += " ( " + operators.AIRLINE_CODE.value;
    } else {
      startAndValue += " " + operators.AIRLINE_CODE.value;
    }
  }

  if (operators.PCC_COUNTRY_CODE.operator === "AND") {
    endAndValue +=
      " " +
      operators.PCC_COUNTRY_CODE.operator +
      " " +
      operators.PCC_COUNTRY_CODE.value;
  }
  if (operators.PCC_COUNTRY_CODE.operator === "OR") {
    orValue +=
      " " +
      operators.PCC_COUNTRY_CODE.operator +
      " " +
      operators.PCC_COUNTRY_CODE.value;
  }

  if (operators.GDS_CODE.operator === "AND") {
    endAndValue +=
      " " + operators.GDS_CODE.operator + " " + operators.GDS_CODE.value;
  }
  if (operators.GDS_CODE.operator === "OR") {
    orValue +=
      " " + operators.GDS_CODE.operator + " " + operators.GDS_CODE.value;
  }

  if (operators.SEGMENT_DATE.operator === "AND") {
    endAndValue +=
      " " +
      operators.SEGMENT_DATE.operator +
      " " +
      operators.SEGMENT_DATE.value;
  }
  if (operators.SEGMENT_DATE.operator === "OR") {
    orValue +=
      "  " +
      operators.SEGMENT_DATE.operator +
      " " +
      operators.SEGMENT_DATE.value;
  }

  if (
    operators.PCC_COUNTRY_CODE.operator === "OR" ||
    operators.GDS_CODE.operator === "OR" ||
    operators.SEGMENT_DATE.operator === "OR" ||
    operators.AIRLINE_CODE.operator === "OR" ||
    operators.SEGMENT_DATE.operator === "OR"
  ) {
    orValue += " ) ";
  }
  return startAndValue + orValue + endAndValue;
};
